//= require prism.js
//= require prism-code-folder.js
//= require jsl-format.js
//= require content_util.js
//= require content.js
//= require_self

document.addEventListener("DOMContentLoaded", contentReady, false);
